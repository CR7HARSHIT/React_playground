const express = require('express');
const cors = require('cors'); // Import cors
const app = express();
const port = 5500;

// Sample data associated with IDs
const data = {
    '1': 'Data for ID 1',
    '2': 'Data for ID 2',
    '3': 'Data for ID 3',
    '4': 'Data for ID 4'
};

// Middleware
app.use(express.json());
app.use(cors()); // Use CORS middleware

// Route to handle different IDs
app.post('/perform_task', (req, res) => {
    const { id } = req.body;
    const responseData = data[id] || 'No data found for the given ID';
    res.json({ success: true, data: responseData });
});

// Start server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
