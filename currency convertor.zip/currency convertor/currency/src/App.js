import React, { useState } from "react";
import InputBox from "./Hooks/inputBox";
import CurrencyApi from "./Hooks/currencyApi";

const App = () => {
  const [baseCurrency, setBaseCurrency] = useState(null);
  const [currency, setCurrency] = useState(null);
  const [amount, setAmount] = useState(0); // Updated variable name to lowercase

  // Validation to ensure amount is numeric
  const handleAmountChange = (e) => {
    const value = e.target.value;
    if (!isNaN(value)) {
      setAmount(value);
    }
  };

  return (
    <div className="flex flex-col justify-center items-center">
      {/* InputBox for currency selection */}
      <div>
        <InputBox setBaseCurrency={setBaseCurrency} setCurrency={setCurrency} />
      </div>

      {/* Input for amount */}
      <div className="flex flex-col w-full max-w-xs mx-auto mt-4">
        <input
          type="text"
          value={amount}
          onChange={handleAmountChange}
          placeholder="Amount..."
          className="p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Display converted amount */}
      <div className="mt-4">
        <CurrencyApi baseCurrency={baseCurrency} currency={currency} amount={amount} />
      </div>
    </div>
  );
};

export default App;
