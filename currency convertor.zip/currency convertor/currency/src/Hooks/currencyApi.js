import { useState, useEffect } from "react";
import freeCurrencyAPI from "@everapi/freecurrencyapi-js";

const CurrencyApi = ({ currency, baseCurrency, amount }) => {
  const [currencyData, setCurrencyData] = useState(null);
  const [convertedAmount, setConvertedAmount] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
  
    if (!baseCurrency || !currency || !amount) return;

    const client = new freeCurrencyAPI("fca_live_mBIiouZ0ZUoTAGMTlymtA5IplfkY21YBrVhcJF1S");

    
    client
      .latest({
        base_currency: baseCurrency,
        currencies: currency,
      })
      .then((response) => {
        
        const rate = response.data[currency];
        if (rate) {
         
          setConvertedAmount(rate * parseFloat(amount)); 
          setCurrencyData(rate);
        } else {
          setError("Conversion rate not found");
        }
      })
      .catch((err) => {
        setError(err.message);
        console.error("Error fetching currency data:", err);
      });
  }, [baseCurrency, currency, amount]);

  return (
    <div>
      <h1>Currency Conversion</h1>
      {error && <p>Error: {error}</p>}
      {currencyData ? (
        <div>
          <p>
            Conversion Rate: 1 {baseCurrency} = {currencyData} {currency}
          </p>
          <p>
            Converted Amount: {amount} {baseCurrency} = {convertedAmount.toFixed(2)} {currency}
          </p>
        </div>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default CurrencyApi;
