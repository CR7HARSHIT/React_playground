import React, { useState } from 'react';

const InputBox = ({ setBaseCurrency, setCurrency }) => {
  const [localCurrency, setLocalCurrency] = useState('USD'); // Default value
  const [localBaseCurrency, setLocalBaseCurrency] = useState('EUR'); // Default value

  // Update local and parent states for Currency 1
  const handleChange1 = (e) => {
    const newBaseCurrency = e.target.value;
    setLocalBaseCurrency(newBaseCurrency);
    setBaseCurrency(newBaseCurrency);
  };

  // Update local and parent states for Currency 2
  const handleChange2 = (e) => {
    const newCurrency = e.target.value;
    setLocalCurrency(newCurrency);
    setCurrency(newCurrency);
  };

  // Swap local and parent states
  const handleSwap = () => {
    const tempBaseCurrency = localBaseCurrency;
    const tempCurrency = localCurrency;

    setLocalBaseCurrency(tempCurrency);
    setLocalCurrency(tempBaseCurrency);

    setBaseCurrency(tempCurrency);
    setCurrency(tempBaseCurrency);
  };

  return (
    <div className="flex flex-col items-center justify-center w-full m-auto text-4xl text-blue-500 text-center">
      <h1 className="mb-4">Currency Select</h1>

      <div className="flex space-x-4 items-center">
        <div className="flex flex-col items-center">
          <label htmlFor="currency1" className="mb-2">
            Select Currency 1:
          </label>
          <select
            id="currency1"
            onChange={handleChange1}
            value={localBaseCurrency}
            className="p-2 border border-gray-300 rounded"
          >
            <option value="AUD">AUD</option>
            <option value="BGN">BGN</option>
            <option value="BRL">BRL</option>
            <option value="CAD">CAD</option>
            <option value="CHF">CHF</option>
            <option value="CNY">CNY</option>
            <option value="CZK">CZK</option>
            <option value="DKK">DKK</option>
            <option value="EUR">EUR</option>
            <option value="GBP">GBP</option>
            <option value="HKD">HKD</option>
            <option value="HRK">HRK</option>
            <option value="HUF">HUF</option>
            <option value="IDR">IDR</option>
            <option value="ILS">ILS</option>
            <option value="INR">INR</option>
            <option value="ISK">ISK</option>
            <option value="JPY">JPY</option>
            <option value="KRW">KRW</option>
            <option value="MXN">MXN</option>
            <option value="MYR">MYR</option>
            <option value="NOK">NOK</option>
            <option value="NZD">NZD</option>
            <option value="PHP">PHP</option>
            <option value="PLN">PLN</option>
            <option value="RON">RON</option>
            <option value="RUB">RUB</option>
            <option value="SEK">SEK</option>
            <option value="SGD">SGD</option>
            <option value="THB">THB</option>
            <option value="TRY">TRY</option>
            <option value="USD">USD</option>
            <option value="ZAR">ZAR</option>
          </select>
        </div>

        <div className="flex flex-col items-center">
          <label htmlFor="currency2" className="mb-2">
            Select Currency 2:
          </label>
          <select
            id="currency2"
            onChange={handleChange2}
            value={localCurrency}
            className="p-2 border border-gray-300 rounded"
          >
            <option value="AUD">AUD</option>
            <option value="BGN">BGN</option>
            <option value="BRL">BRL</option>
            <option value="CAD">CAD</option>
            <option value="CHF">CHF</option>
            <option value="CNY">CNY</option>
            <option value="CZK">CZK</option>
            <option value="DKK">DKK</option>
            <option value="EUR">EUR</option>
            <option value="GBP">GBP</option>
            <option value="HKD">HKD</option>
            <option value="HRK">HRK</option>
            <option value="HUF">HUF</option>
            <option value="IDR">IDR</option>
            <option value="ILS">ILS</option>
            <option value="INR">INR</option>
            <option value="ISK">ISK</option>
            <option value="JPY">JPY</option>
            <option value="KRW">KRW</option>
            <option value="MXN">MXN</option>
            <option value="MYR">MYR</option>
            <option value="NOK">NOK</option>
            <option value="NZD">NZD</option>
            <option value="PHP">PHP</option>
            <option value="PLN">PLN</option>
            <option value="RON">RON</option>
            <option value="RUB">RUB</option>
            <option value="SEK">SEK</option>
            <option value="SGD">SGD</option>
            <option value="THB">THB</option>
            <option value="TRY">TRY</option>
            <option value="USD">USD</option>
            <option value="ZAR">ZAR</option>
          </select>
        </div>
      </div>

      <div>
        <button onClick={handleSwap} className="mt-4 p-2 bg-blue-500 text-white rounded">
          Swap
        </button>
      </div>
    </div>
  );
};

export default InputBox;
