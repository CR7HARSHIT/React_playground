import PasswordGenrator from './components/PasswordGenrator';

function App() {
  return (
    <div className="flex items-center justify-center h-screen w-screen">
      <PasswordGenrator />
    </div>
  );
}

export default App;
