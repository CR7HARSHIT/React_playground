import React, { useState, useCallback , useEffect} from "react";

const PasswordGenerator = () => {
  const [password, setPassword] = useState("");
  const [length, setLength] = useState(12);
  const [numbers, setNumbers] = useState(false);
  const [characters, setCharacters] = useState(false);

  const generatePassword = useCallback(() => {
    let ch = "aqzxswedcvfrtgbnhyujmkiolpAQZXSWEDCVFRTGBNHYUJMKIOLP";
    if (numbers) {
      ch += "1234567890"; // Add numbers if `numbers` is true
    }
    if (characters) {
      ch += "!@#$%^&*()?/.,><"; // Add special characters if `characters` is true
    }

    let ans = "";

    for (let i = 0; i < length; i++) {
      let index = Math.floor(Math.random() * ch.length);
      ans += ch[index];
    }

    setPassword(ans);
  }, [length, numbers, characters , setPassword]);

  useEffect(() => {
        
      
    return generatePassword()
      
    
  }, [length, numbers, characters , generatePassword])
  

  return (
    <div className="flex flex-col items-center justify-center h-[150px] w-[900px] bg-slate-500 border border-black p-4">
      <div className="flex flex-row w-full h-[20%] items-center justify-center space-x-4">
        <input
          type="text"
          className="w-[70%] p-2 border border-gray-300 rounded"
          placeholder="Generated password"
          value={password}
          readOnly
        />
        <button
          
          className="bg-blue-900 text-white px-4 py-2 rounded"
        >
          Copy
        </button>
      </div>
      <div className="flex flex-row flex-grow w-full mt-4 justify-around items-center p-4">
        <div className="flex items-center">
          <input
            type="range"
            id="slider"
            value={length}
            min="4"
            max="20"
            className="w-32"
            onChange={(e) => setLength(Number(e.target.value))}
          />
          <label htmlFor="slider" className="ml-2">
            Length: {length}
          </label>
        </div>
        <div className="flex items-center">
          <input
            type="checkbox"
            id="checkbox1"
            className="mr-2"
            checked={numbers}
            onChange={(e) => setNumbers(e.target.checked)}
          />
          <label htmlFor="checkbox1">Numbers</label>
        </div>
        <div className="flex items-center">
          <input
            type="checkbox"
            id="checkbox2"
            className="mr-2"
            checked={characters}
            onChange={(e) => setCharacters(e.target.checked)}
          />
          <label htmlFor="checkbox2">Characters</label>
        </div>
      </div>
    </div>
  );
};

export default PasswordGenerator;
